<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionA extends Model
{
    protected $table = 'section_a';
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Sections;
use \App\SectionA;  
use \App\SectionB;  
use App\SectParameter;  
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Validator;

class SectionsController extends Controller
{
    public function index(){
        $parts = \App\Parts::select('id', 'part_no')->get();
         $sections = \App\Sections::select('id', 'section_name')->get();
         $sect_a = DB::table('section_a')->select('id','parameter_name', 'specifications', 'test_method')->get();
//         foreach($sections as $sects){
//             dd($sects['section_name']);
//         }
//         dd($sect_a);
            return view('welcome', array('parts'=> $parts, 'sections'=>$sections, 'parameters'=>$sect_a));

    }
    
    public function getsections(Request $req){
         //$sections = \App\Sections::select('section_name')->first()->where('id ',$req);
    }
    
    public function store(Request $req){
//        var_dump($req->sel_part);   
        $input = $req->all();
        $data = request()->validate([
           'param' => 'required'
        ]);
        
        $sects = new SectionA();
        for ($i = 0; $i < count($input['spec']); $i++) {  
            if(!empty($input['param'][$i])){
                $sects->parameter_name = $input['param'][$i];
            }
            if(!empty($input['spec'][$i])){
                 $sects->specifications = $input['spec'][$i];
            }
            if(!empty($input['tm'][$i])){
                 $sects->test_method = $input['tm'][$i];
            }
        }    
        $sects->save();
        
        $sectParamerterObj = new SectParameter();
        $sectParamerterObj->part_id = $input['sel_part'];
        $sectParamerterObj->section_id = $input['sel_sect'];
        $sectParamerterObj->save();

        
        $sectionBObj = new SectionB();
        for ($i = 1; $i <= 3; $i++) {
            
            if(!empty($input['element_'.$i])){
                $sectionBObj->element_name = $input["element_".$i];
            }
             if(!empty($input['min_'.$i])){
                $sectionBObj->min = $input["min_".$i];
            }
             if(!empty($input['max_'.$i])){
                $sectionBObj->max = $input['max_'.$i];
            }
        }
        $sectionBObj->save();
        
       
//        dd($sectParamerterObj);
        return view('met');       //->withErrors($validator);
    }
    
    public function getMetform() {
        
//        $data = DB::select('part_id', 'section_id')->table('sect_parameter')->get();
        $data = DB::select(DB::raw('Select p.part_no, s.section_name from sect_parameter as sp inner join sections s ON sp.section_id=s.id'
                . ' inner join parts as p ON p.id=sp.part_id group by sp.section_id, sp.part_id, s.section_name, p.part_no'));
        //$getSection = SectParameter::select('part_id','section_id')->groupBy('section_id')->get();
        //dd($data[0]->part_no);
        $section_b = DB::select('select * from sectionb');
        $section_a = DB::select('select * from  section_a');
        
        return view('met')->with('sectParameter', $data)->with('part_no', $data[0]->part_no)->with('section_b', $section_b)->with('section_a', $section_a);        //->with('sectionA', $sects);
        //->with('sectParameter', $sectParamerterObj);
    }
    
    public function addMetTest(Request $request){
        $input = $request->all();
        $validate = $request->validate([
            //'min' => ['required'],
            'actual' => ['required'],
            'obs' =>['required']                    // ['required_if:spec, tm '],
        ]); 
        $data = DB::select(DB::raw('Select s.section_name, p.part_no  from sect_parameter as sp inner join sections s ON sp.section_id=s.id'
                . ' inner join parts as p ON p.id=sp.part_id group by sp.section_id, sp.part_id, s.section_name, p.part_no'));
        $section_b = DB::select('select * from sectionb');
        $section_a = DB::select('select * from  section_a');
        
         $sects = new SectionA();
       
        for ($i = 0; $i < count($input['obs']); $i++) {  
            if(!empty($input['obs'][$i])){
                $sects->observation = $input['obs'][$i];
            }
            if(!empty($input['spec'][$i])){
                 $sects->specifications = $input['spec'][$i];
            }
            if(!empty($input['tm'][$i])){
                 $sects->test_method = $input['tm'][$i];
            }
             if(!empty($input['param'][$i])){
                $sects->parameter_name = $input['param'][$i];
            }
              $sects->save();
        } 
       
        $sectionBObj = new SectionB();
        for ($i = 1; $i < count($input['actual']); $i++) {
            if(!empty($input['element'])){
                $sectionBObj->element_name = $input["element"][$i];
            }
            if(!empty($input['min'])){
                $sectionBObj->min = $input["min"][$i];
            }
            if(!empty($input['max'])){
                $sectionBObj->max = $input['max'][$i];
            }
            if(!empty($input['actual'])){
                $sectionBObj->actual = $input['actual'][$i];
            }
//            dd($sectionBObj['actual']);
            
        } 
        $sectionBObj->save();
        
        return view('met')->withSuccess('Great! Form successfully submitted')->with('sectParameter', $data)->with('part_no', $data[0]->part_no)->with('section_b', $section_b)->with('section_a', $section_a);        // ->with('sectionA', $sects)
    }
}
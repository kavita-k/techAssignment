<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectionB extends Model
{
     protected $table = 'sectionb';
}

<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class SectParameter extends Model
{
    protected $table = 'sect_parameter';
}

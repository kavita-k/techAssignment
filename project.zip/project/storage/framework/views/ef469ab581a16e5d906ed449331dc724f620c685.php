<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title>Tech Requirements</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet">        
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet"> 
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>         
    <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.1/dist/jquery.validate.min.js"></script>
    <!-- Latest compiled and minified CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }
        </style>
    </head>
    <body>
        <div class="container panel panel-default ">
            <h2 class="panel-heading"> Met Testing form</h2>
            <form id="met_test" method="post" action=" <?php echo e(addMetTest); ?> ">
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>"> 
                <div class="form-group" class="">
                    <span><h5>&nbsp; Part Number </h5> <?php echo e($part_no); ?></span>
                    <?php //var_dump($sectParameter); die(); ?>
                </div><!-- comment -->
                    <div class='form-group'>
                        <div> Section Name : </div>
                        <div style="">

                        <?php $__currentLoopData = $sectParameter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectParams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                         
                            <div><?php echo e($sectParams->section_name); ?> </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <div class="form-group form-group-sm">
                            <div id='section_b_data'>
                                <table id="section_B" class="table table-bordered table-striped">
                                <tbody>
                                    <tr>
                                        <th>Elements</th>
                                        <?php $__currentLoopData = $section_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                                            <td> <input type='text' id='element_<?php echo $sectB->id; ?>' name='element_<?php echo $sectB->id; ?>' value="<?php echo e($sectB->element_name); ?>"></<td>
                                            <td> <input type='text' id='element[]' name='element[]'></<td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    
                                    <tr>
                                        <th>Min</th>
                                        <?php $__currentLoopData = $section_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                                            <td> <input type='text' id='element_<?php echo $sectB->id; ?>' name='element_<?php echo $sectB->id; ?>' value="<?php echo e($sectB->min); ?>"></<td>
                                                <td> <input type='text' id='min[]' name='min[]'></<td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                        
                                    <tr>
                                        <th>Max</th>
                                        <?php $__currentLoopData = $section_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                                            <td> <input type='text' id='element_<?php echo $sectB->id; ?>' name='element_<?php echo $sectB->id; ?>' value="<?php echo e($sectB->max); ?>"></<td>
                                                <td> <input type='text' id='max[]' name='max[]'></<td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                    
                                    <tr>
                                        <th>Actual</th>
                                        <?php $__currentLoopData = $section_b; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sectB): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                                        
                                            <td> <input type='text' id='element_<?php echo $sectB->id; ?>' name='element_<?php echo $sectB->id; ?>' value=""></<td>
                                                <td> <input type='text' id='actual[]' name='actual[]'></<td>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tr>
                                </table>
                            </div>
                            </div>    
                        
                    </table>
                </div>
                
                <div class="form-group">
                    <h6>Section A</h6>
                           <table id="editable" class="table table-bordered table-striped">
                     <thead>
                         <tr>
                             <th>Sequence</th>
                             <th>Parameters</th>
                             <th>Specifications </th>
                             <th>Test Method</th>                             
                             <th>Observation</th>                             
                         </tr>
                     </thead>
                     <tbody>
                         <?php $__currentLoopData = $section_a; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $param): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                         <tr>
                             <td><?php echo e($param->id); ?></td>
                             <td><input type="text"  name="param[]" id="param_<?php echo $param->id; ?>" value="<?php echo $param->parameter_name; ?>">
                             <span class="text-danger"><?php echo e($errors->first('param')); ?></span></td>
                             
                             <td><input type="text"  name="spec[]" id="spec_<?php echo $param->id; ?>" value="<?php echo $param->specifications; ?>" ></td>
                             <td><input type="text"  name="tm[]" id="tm_<?php echo $param->id; ?>" value="<?php echo $param->test_method; ?>"> </td>
                             <td><input type="text"  name="obs[]" id="obs[]" value="<?php echo $param->observation; ?>"> </td>
                         </tr>
                         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         
                     </tbody>
                 </table>
                </div>
                <div class="form-group" id="">
                    <span id="errors"></span>
                </div>
                <div class="form-group">
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger">
                            <ul>
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>
                <div class='form-group'>
                    <button type="submit" name='addMetForm' id='addMetForm'>Submit</button>
                </div>
                
            </form>
        </div>            
    </body>
    
</html>
<script type="text/javascript">     
    
$.ajaxSetup({
    headers: {
        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
    }
});

   
if ($("#met_test").length > 0) {
    $("#met_test").validate({
        rules: {
            actual: {
              required: true
            },
            obs:{
                required:true
            }
        },
        messages: {
            actual: 'Please enter actual value.',
            obs: 'Please enter observation value.'
          },
        errorPlacement: function (error, element) {
//            var input = $("#errors").values();
            var input = element;
            alert(error);
            error.appendTo($("." + input));
         },
        submitHandler: function (form) {
//        return false;
        form.submit();
      }
    });
    }
    
    
$(document).ready(function(){

//$.validator.addMethod("requireObs", function (value, element, options)
//{
//    //we need the validation error to appear on the correct element
//    var targetEl = $('input[name="'+obs.data+'"]');
//    alert(targetE1);
//    
////    (bothEmpty) ? targetEl.addClass('error') : targetEl.removeClass('error');
////    return !bothEmpty;
//},
//);

 
});
       
    
</script><?php /**PATH C:\xampp\htdocs\laraweb\project\resources\views/met.blade.php ENDPATH**/ ?>
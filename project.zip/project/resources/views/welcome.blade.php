<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-token" content="{{ csrf_token() }}">
        <title>Tech Requirements</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,600" rel="stylesheet"> 
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
        <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.0/jquery.validate.min.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
    <!-- Latest compiled and minified JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
        <!-- Styles -->
        <style>
            html, body {
                background-color: #fff;
                color: #636b6f;
                font-family: 'Nunito', sans-serif;
                font-weight: 200;
                height: 100vh;
                margin: 0;
            }

            .full-height {
                height: 100vh;
            }

            .flex-center {
                align-items: center;
                display: flex;
                justify-content: center;
            }

            .position-ref {
                position: relative;
            }

            .top-right {
                position: absolute;
                right: 10px;
                top: 18px;
            }

            .content {
                text-align: center;
            }

            .title {
                font-size: 84px;
            }

            .links > a {
                color: #636b6f;
                padding: 0 25px;
                font-size: 13px;
                font-weight: 600;
                letter-spacing: .1rem;
                text-decoration: none;
                text-transform: uppercase;
            }

            .m-b-md {
                margin-bottom: 30px;
            }
        </style>
    </head>
    <body>
        <div class="container panel panel-default ">
            <h2 class="panel-heading"> Tech Requirements</h2>
            <form id="tech_form" method="post" action="/store">
                <input type="hidden" name="_token" value="{{ csrf_token() }}"> 
            <div class="form-group" class="col-sm-1">
                Part Number : <select id='sel_part' name='sel_part'  class="form-control col-sm-1">
                <option value='0'> Select part number</option>
                <!-- Read part number -->
                @foreach($parts as $part)
                  <option value='{{ $part->id }}'>{{ $part->part_no }}</option>
                @endforeach

             </select>
            </div>
             <div class="form-group">
                 <!--<span class="text-danger" id="email-error"></span>-->                 
                 <h5> Section Sequence</h5>
                Select section name <select id='sel_sect' name='sel_sect'  class="form-control col-sm-1">
                    <option value='0'> Select Section name</option>                   
                    @foreach($sections as $sects)
                      <option value='{{ $sects->id }}'>{{ $sects->section_name }}</option>
                    @endforeach
                 </select><nbsp/>
                 <button  id="add_sectA" class="form-control btn btn-success" onclick="show_section()">Add</button>
             </div>
            <div class='form-group'>
                <table id="section_info" class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Action</th>
                            <th>Sequence</th>
                            <th>Section name </th>                                                         
                        </tr>
                    </thead>
                    <tbody>
                    <div id='sequence'>
                    </div>
                    </tbody>
                </table>
            </div>
            
             <div class="form-group" id="section1">
                 <h5> Section A</h5>
                 <table id="editable" class="table table-bordered table-striped">
                     <thead>
                         <tr>
                             <th>Sequence</th>
                             <th>Parameters</th>
                             <th>Specifications </th>
                             <th>Test Method</th>                             
                         </tr>
                     </thead>
                     <tbody>
                         @foreach($parameters as $param)
                         <tr>
                             <td>{{ $param->id }}</td>
                             <td><input type="text"  name="param[]" id="param_<?php echo $param->id; ?>"></td>
                             
                             <td><input type="text"  name="spec[]" id="spec_<?php echo $param->id; ?>"></td>
                             <td><input type="text"  name="tm[]" id="tm_<?php echo $param->id; ?>"></td>
                         </tr>
                         @endforeach
                     
                     </tbody>
                 </table>
                 <div>
                     @if ($errors->has('param'))
                     <span class="text-danger">{{ $errors->first('param') }}</span>
                     @endif
                 </div>
                 
                 <div class='form-group'>
                    <div id='section_b_data'>
                        <table id="section_B" class="table table-bordered table-striped">
                            <tbody>
                                <tr>
                                    <th>Elements</th>
                                    <td> <input type='text' id='element_1' name='element_1'></<td>
                                    <td> <input type='text' id='element_2' name='element_2'></<td>
                                        <td> <input type='text' id='element_3' name='element_3'></<td>
                                </tr>
                                <tr>
                                    <th>Min</th>
                                   <td> <input type='text' id='min_1' name='min_1'></<td>
                                    <td> <input type='text' id='min_2' name='min_2'></<td>
                                        <td> <input type='text' id='min_3' name='min_3'></<td>
                                </tr>
                                <tr> 
                                   <th>Max </th>
                                    <td> <input type='text' id='max_1' name='max_1'></<td>
                                    <td> <input type='text' id='max_2' name='max_2'></<td>
                                    <td> <input type='text' id='max_3' name='max_3'></<td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
             </div>
                <div id="error_validate"></div>
            <div class="form-group">
                <button type="submit" class="btn btn-primary submitBtn">Submit</button>
            </div>
            </form>
        </div>
    </body>
    

   <script type="text/javascript">      
    $.ajaxSetup({
        headers: {
            'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
        }
    });
    
  $(document).ready(function () {
       
//    $(document).on('change', '#sel_sect', function() {
//        var sect_id =  $(this).val();
//        var s = $(this).parent();
//        
//        var op = "";
//        alert(sect_id);
//        $.ajax({
//            type: 'POST',
//            url: '/getSections',
//            data: { 'id':sect_id },
//            dataType: 'json',     
//            success: function(data) {                
//                console.log(data.section_name);
//
//                //a.find('.aircraft_id').val(data.aircraft_id); 
//                // do you want to display id or registration name?
//            },
//            error:function(){
//            }
//        });
//    });
    
    
});

    
         
    function show_section(){
        $("#section1").show();
    }
    </script>
</html>